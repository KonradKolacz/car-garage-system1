package com.example.test04system1.model;

import com.example.test04system1.domain.Alert;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class AlertContainer {

    private final Map<Alert, Integer> map = new HashMap<>();

    public void addAlert(Alert alert) {
        map.put(alert, map.containsKey(alert) ? map.get(alert) + 1 : 1);
    }

    public void removeAlert(Alert alert) {
        map.remove(alert);
    }

    public int getNumberOfAlertRepetitions(Alert alert) {
        return map.get(alert);
    }

}
