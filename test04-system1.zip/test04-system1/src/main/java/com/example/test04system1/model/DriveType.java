package com.example.test04system1.model;

public enum DriveType {
    PETROL, DIESEL, HYBRID, ELECTRIC, LPG
}
