package com.example.test04system1.domain;

import com.example.test04system1.model.DriveType;
import lombok.*;

import javax.persistence.*;

@Entity
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Car {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String mark;
    private String model;
    private int yearOfProduction;
    @Enumerated(EnumType.STRING)
    private DriveType driveType;
    @ManyToOne
    @ToString.Exclude
    private Garage garage;
}
