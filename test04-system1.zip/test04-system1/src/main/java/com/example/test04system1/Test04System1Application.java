package com.example.test04system1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Test04System1Application {

	public static void main(String[] args) {
		SpringApplication.run(Test04System1Application.class, args);
	}

}
