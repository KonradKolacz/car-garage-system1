package com.example.test04system1.service;

import com.example.test04system1.domain.Car;
import com.example.test04system1.domain.Garage;
import com.example.test04system1.exception.*;
import com.example.test04system1.repository.GarageRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class GarageService {

    private final GarageRepository garageRepository;
    private final CarService carService;
    private final ValidateService validateService;

    public Garage findById(Long id) {
        return garageRepository.findById(id).orElseThrow(() -> new ObjectNotFoundException(id, Garage.class.getName()));
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {ObjectNotFoundException.class, NoFreeParkingSpacesException.class, ForbiddenTypeLPGException.class, CarAssignedToGarageException.class})
    public Garage addCar(Long garageId, Long carId) {
        Garage garageById = findById(garageId);
        Car carById = carService.findById(carId);

        validateService.validateAvailableSpaceInGarage(garageById, carById);
        validateService.validateDriveType(garageById, carById);
        validateService.validateCarIsNotParked(garageById, carById);

        garageById.addCar(carById);
        return garageById;
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {ObjectNotFoundException.class, NoCarInGarageException.class})
    public Garage removeCar(Long garageId, Long carId) {
        Garage garageById = findById(garageId);
        Car carById = carService.findById(carId);

        validateService.validateCarInThatGarage(garageById, carById);

        garageById.removeCar(carById);
        return garageById;
    }
}
